const merge = require("webpack-merge");
const common = require("./webpack.common");

module.exports = merge(common.config, {
    mode: "production",
    devtool: "source-maps",
    module: {
        rules: [
            /**
             * HTML
             */
            {
                test: /\.html$/,
                use: [{
                    loader: "html-loader",
                    options: {
                        interpolate: true
                    }
                }]
            },
        ]
    }
});