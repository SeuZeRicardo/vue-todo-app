const webpack = require("webpack");
const merge = require("webpack-merge");
const common = require("./webpack.common.js");

module.exports = merge(common.config, {
    mode: "development",
    devtool: "cheap-eval-source-maps",
    module: {
        rules: [
            /**
             * HTML
             */
            {
                test: /\.html$/,
                use: [
                    {
                        loader: "html-loader",
                        options: {
                            minimize: false,
                            interpolate: true
                        }
                    }
                ]
            },
        ]
    }
});