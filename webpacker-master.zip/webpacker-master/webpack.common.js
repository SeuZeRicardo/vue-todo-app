const path = require("path");
const CleanWebpackPlugin = require("clean-webpack-plugin");
const HtmlWebpackPlugin = require("html-webpack-plugin");

const paths = {
    assets: path.join(__dirname, "/src/assets"),
    html: path.join(__dirname, "/src/html"),
    scss: path.join(__dirname, "/src/scss"),
    js: path.join(__dirname, "/src/js"),
    pages: path.join(__dirname, "/src/pages"),
    output: path.join(__dirname, "/dist")
};

function page(name, chunks, ext = ".html") {
    return new HtmlWebpackPlugin({
        filename: name + ".html",
        template: path.join(paths.pages, name + ext),
        chunks: chunks,
        inject: true
    });
}

exports.config = {

    entry: {
        "main": path.join(paths.pages, "main.js")
    },

    output: {
        filename: "[name].js",
        chunkFilename: "js/[name].js",
        path: paths.output,
        // publicPath: "dist"
    },

    resolve: {
        alias: {
            "*scss": paths.scss
        }
    },

    devServer: {
        port: 8080,
        host: "localhost",
        open: true,
        contentBase: "./dist",
        hot: false
    },

    module: {
        rules: [
            /**
             * javascript
             */
            {
                test: /\.js$/,
                use: [
                    /* Compilação de código em ES6. */
                    {
                        loader: "babel-loader",
                        options: {
                            presets: ["env"],
                            plugins: ["syntax-dynamic-import"]
                        }
                    }
                ],
                exclude: /node_modules/
            },
        ]
    },

    plugins: [

        page("index", ["main"]),

        new CleanWebpackPlugin(["dist"]),

        // new webpack.ProvidePlugin({
        //     $: "jquery",
        //     _: "lodash"
        // }),
    ]

}















